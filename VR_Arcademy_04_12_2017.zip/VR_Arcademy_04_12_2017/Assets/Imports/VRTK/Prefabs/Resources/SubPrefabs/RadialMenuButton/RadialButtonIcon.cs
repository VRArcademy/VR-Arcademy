﻿namespace VRTK
{
    using UnityEngine;

    public class RadialButtonIcon : MonoBehaviour
    {
        //Easier than getting tag, can't change through project settings
    }
}